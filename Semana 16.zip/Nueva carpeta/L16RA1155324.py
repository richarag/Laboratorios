print("Semana No. 16: Ejercicio 1, Ricardo Aragón 1155324")
import random
estructura=[]
def Vector(estructura):
    for i in range(10):
        H=random.randint(1,100)
        estructura.append(H)
    return estructura
def Promedio(estructura):
    suma=0
    for cantidad in estructura:
        suma+=cantidad
    prom=suma/len(estructura)
    return prom
def ParesyImpares(estructura):
    Paressumatoria=0
    Imparessumatoria=0
    for d in range(len(estructura)):
        if d%2==0:
            Paressumatoria+=estructura[d]
        else:
            Imparessumatoria+=estructura[d]
    print("Su suma de pares son", Paressumatoria)
    print("Su suma de impares son", Imparessumatoria)
def ContarlosImparyPar(matriz):
    pares=0
    impares=0
    for M in range(len(matriz)):
        for F in range(len(matriz[M])):
            if matriz[M][F]%2==0:
                pares+=1
            else:
                impares+=1
    print("La cantidad de números pares es", pares)
    print("La cantidad de números impares", impares)
def NumeroMayoryMenor(matriz):
    Nmayor=matriz[0][0]
    Nmenor=matriz[0][0]
    for d in range(len(matriz)):
        for C in range(len(matriz[d])):
            if matriz[d][C]>Nmayor:
                Nmayor=matriz[d][C]
            elif matriz[d][C]<Nmenor:
                Nmenor=matriz[d][C]
    print("su numero mayor es ", Nmayor)
    print("su numero menor es", Nmenor)
Vector(estructura)
print(estructura)
print("Su promedio es: ", Promedio(estructura))
print("La longitud de su arreglo es: ", len(estructura))
ParesyImpares(estructura)

print("Semana 16: Ejercicio 2, Ricardo Aragón 1155324")
filas=int(input("Ingrese la cantidad de filas: "))
columnas=int(input("Ingrese la cantidad de columnas "))
matriz=[]
for d in range(filas):
    t=[]
    for j in range(columnas):
        h=random.randint(1,1001)
        t.append(h)
    matriz.append(t)
print(matriz)
ContarlosImparyPar(matriz)
NumeroMayoryMenor(matriz)

        


