print("Ricardo Andres Aragón Elias 1155324") 
Dian=int(input("Ingrese su dia de nacimiento")) 
Mesn=int(input("Ingrese su mes de nacimiento"))
Añon=int(input("Ingrese su año de nacimiento")) 
if (Mesn==3 and Dian>=21) or (Mesn==4 and Dian<=19): 
    print("Su signo zodiacal es Aries") 
elif (Mesn == 4 and Dian>=20) or (Mesn==5 and Dian<=20):
     print("Su signo zodiacal es Tauro")
elif (Mesn== 5 and Dian>=21) or (Mesn==6 and Dian<=20):
        print("Su signo zodiacal es Geminis")
elif (Mesn == 6 and Dian>=21) or (Mesn==7 and Dian<=22):
        print("Su signo zodiacal es Cancer")
elif (Mesn == 7 and Dian>=23) or (Mesn==8 and Dian<=22):
        print("Su signo zodiacal es Leo")
elif (Mesn== 8 and Dian>=23) or (Mesn==9 and Dian<=22):
        print("Su signo zodiacal es Virgo")
elif (Mesn==9 and Dian>=23) or (Mesn==10 and Dian<=22):
        print("Su signo zodiacal es Libra")
elif (Mesn== 10 and Dian>=23) or (Mesn==11 and Dian<=21):
        print("Su signo zodiacal es Escorpio")
elif (Mesn== 11 and Dian>=22) or (Mesn==12 and Dian<=21):
        print("Su signo zodiacal es Sagitario")
elif (Mesn== 12 and Dian>=22) or (Mesn==1 and Dian<=19):
        print("Su signo zodiacal es Capricornio")
elif (Mesn== 1 and Dian>=20) or (Mesn==2 and Dian<=18):
        print("Su signo zodiacal es Acuario")
elif (Mesn== 2 and Dian>=19) or (Mesn==3 and Dian<=20):
        print("Su signo zodiacal es Pisis")
